const mysql = require('mysql2')
const con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "binhan2001",
    database: "ThietBiPhongHoc"
})

module.exports = con